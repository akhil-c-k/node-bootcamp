const mongoose = require('mongoose');
const dotenv = require('dotenv');

process.on('uncaughtException', (err) => {
  console.log('unhandled exception ... shutting down');
  console.log(err.name, err.message);

  server.close(() => {
    //uncleaned code so should terminate the process
    process.exit(1);
  });
});

dotenv.config({ path: `${__dirname}/config.env` });
const app = require('./app');

const DB = process.env.DATABASE.replace(
  '<PASSWORD>',
  process.env.DATABASE_PASSWORD
);

mongoose
  .connect(DB, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log('DB connection successful!');
  });

//* beware of this path. use __dirname if the rout path not recogonosed
const port = process.env.PORT || 3000;
const server = app.listen(port, () => {
  console.log(process.env.NODE_ENV);
  console.log(`app runnig in port ${port}`);
});

//unhandled rejection handling
process.on('unhandledRejection', (err) => {
  console.log('unhandled rejection ... shutting down');
  console.log(err);

  server.close(() => {
    process.exit(1);
  });
  //1 uncalled exception and code 0 for success
});
