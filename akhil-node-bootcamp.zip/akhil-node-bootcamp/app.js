const express = require('express');
const morgan = require('morgan');
const AppError = require('./utils/appError');
const globalErrorHandler = require('./controllers/errorController');
const tourRouter = require('./routes/tourRoutes');
const userRouter = require('./routes/userRoutes');

const app = express();

//middleware: can able to modify incoming request data
//middleware======================================================================================

if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

app.use(express.json());
// here serving static html page
app.use(express.static(`${__dirname}/public`));
//just get function and root router
//need cb for process something
//GET-------------------------->

//* create middleware

app.use((req, res, next) => {
  req.requestTime = new Date().toISOString();
  next();
});

// creating a individual router so for example wherever we use tour router that place only endpoint needed
// because anyway tourRouter will process '/api/v1/tours'

//place mounting router here so that it wont get created before defention or declared variable
app.use('/api/v1/tours', tourRouter);
app.use('/api/v1/users', userRouter);
//listen : call back function will start as soon as listen start to listen then events
app.all('*', (req, res, next) => {
  next(new AppError(`cant find ${req.originalUrl} on this server`, 404));
});

//the above error recogonise as error handling router and next willmake sure error handling middleware running
app.use(globalErrorHandler);

module.exports = app;
